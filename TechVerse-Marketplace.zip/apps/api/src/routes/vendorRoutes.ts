import express from 'express';
import { getVendorProfile, updateVendorProfile } from '../controllers/vendorController';
import { protect, authorize } from '../middleware/authMiddleware';

const router = express.Router();

router.get('/profile', protect, authorize('vendor'), getVendorProfile);
router.put('/profile', protect, authorize('vendor'), updateVendorProfile);

export default router;
