import React, { useState } from 'react';
import { Outlet, Navigate, Link, useLocation } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { RootState } from '../store/store';
import { logout } from '../store/slices/authSlice';
import { LayoutDashboard, ShoppingBag, Users, Settings, LogOut, Menu } from 'lucide-react';
import { Button } from '@techverse/ui';

export const AdminLayout: React.FC = () => {
  const { user, isAuthenticated } = useSelector((state: RootState) => state.auth);
  const dispatch = useDispatch();
  const location = useLocation();
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  if (!isAuthenticated) {
    return <Navigate to="/login" replace state={{ from: location }} />;
  }

  // Define navigation based on role (Admin vs Vendor)
  const navItems = user?.role === 'admin' || user?.role === 'superadmin' ? [
    { name: 'Dashboard', path: '/', icon: LayoutDashboard },
    { name: 'Products', path: '/products', icon: ShoppingBag },
    { name: 'Users', path: '/users', icon: Users },
    { name: 'Vendors', path: '/vendors', icon: Users },
    { name: 'Settings', path: '/settings', icon: Settings },
  ] : [
    { name: 'Dashboard', path: '/', icon: LayoutDashboard },
    { name: 'My Products', path: '/products', icon: ShoppingBag },
    { name: 'Orders', path: '/orders', icon: ShoppingBag },
    { name: 'Store Profile', path: '/store-profile', icon: Settings },
  ];

  return (
    <div className="flex h-screen bg-gray-50 dark:bg-dark-900 transition-colors">
      {/* Sidebar */}
      <aside className={`bg-white dark:bg-dark-800 border-r border-gray-200 dark:border-dark-700 transition-all duration-300 ${isSidebarOpen ? 'w-64' : 'w-20'}`}>
        <div className="h-16 flex items-center justify-between px-4 border-b border-gray-200 dark:border-dark-700">
          {isSidebarOpen && <span className="text-xl font-bold text-primary-600">TechVerse</span>}
          <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="p-2 rounded-md hover:bg-gray-100 dark:hover:bg-dark-700 text-gray-500">
            <Menu size={20} />
          </button>
        </div>
        <nav className="p-4 space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.name}
                to={item.path}
                className={`flex items-center space-x-3 px-3 py-2 rounded-md transition-colors ${isActive ? 'bg-primary-50 text-primary-600 dark:bg-primary-900/50 dark:text-primary-400' : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-dark-700'}`}
              >
                <Icon size={20} />
                {isSidebarOpen && <span>{item.name}</span>}
              </Link>
            );
          })}
        </nav>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="h-16 bg-white dark:bg-dark-800 border-b border-gray-200 dark:border-dark-700 flex items-center justify-end px-8">
          <div className="flex items-center space-x-4">
            <span className="text-sm font-medium dark:text-white">
              Hello, {user?.name} ({user?.role})
            </span>
            <Button variant="outline" size="sm" className="flex items-center space-x-2" onClick={() => dispatch(logout())}>
              <LogOut size={16} />
              <span>Logout</span>
            </Button>
          </div>
        </header>

        {/* Main section */}
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50 dark:bg-dark-900 p-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
};
