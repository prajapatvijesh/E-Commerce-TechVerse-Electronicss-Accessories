import { Response } from 'express';
import { Order } from '../models/Order';
import { AuthRequest } from '../middleware/authMiddleware';
import { ActivityLog } from '../models/ActivityLog';

// @desc    Get Sales Report
// @route   GET /api/reports/sales
// @access  Private/Admin
export const getSalesReport = async (req: AuthRequest, res: Response) => {
  try {
    const orders = await Order.find({ isPaid: true }).sort({ createdAt: -1 });
    // In a real app, you would aggregate by day, week, month, etc.
    res.json({ status: 'success', data: orders });
  } catch (error: any) {
    res.status(500).json({ status: 'error', message: error.message });
  }
};

// @desc    Get Activity Logs
// @route   GET /api/reports/activity
// @access  Private/Admin
export const getActivityLogs = async (req: AuthRequest, res: Response) => {
  try {
    const logs = await ActivityLog.find().populate('user', 'name email').sort({ createdAt: -1 }).limit(100);
    res.json({ status: 'success', data: logs });
  } catch (error: any) {
    res.status(500).json({ status: 'error', message: error.message });
  }
};
