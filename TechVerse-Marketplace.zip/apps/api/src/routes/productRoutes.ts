import express from 'express';
import { getProducts, getProductBySlug, createProduct } from '../controllers/productController';
import { protect, authorize } from '../middleware/authMiddleware';

const router = express.Router();

router.route('/')
  .get(getProducts)
  .post(protect, authorize('vendor', 'admin', 'superadmin'), createProduct);

router.route('/:slug').get(getProductBySlug);

export default router;
