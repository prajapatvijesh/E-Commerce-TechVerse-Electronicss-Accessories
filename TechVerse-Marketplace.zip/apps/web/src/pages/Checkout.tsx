import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button, Input } from '@techverse/ui';
import { useSelector, useDispatch } from 'react-redux';
import { RootState } from '../store/store';
import { clearCart } from '../store/slices/cartSlice';

import { useMutation } from '@tanstack/react-query';
import axios from 'axios';

export const Checkout: React.FC = () => {
  const { cartItems } = useSelector((state: RootState) => state.cart);
  const { user } = useSelector((state: RootState) => state.auth);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [postalCode, setPostalCode] = useState('');
  const [country, setCountry] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('Credit Card (Demo)');

  const orderMutation = useMutation({
    mutationFn: async (orderData: any) => {
      const config = {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${user?.token}`,
        },
      };
      const res = await axios.post('/api/orders', orderData, config);
      return res.data;
    },
    onSuccess: () => {
      dispatch(clearCart());
      alert('Order placed successfully!');
      navigate('/order/success');
    },
    onError: (err: any) => {
      alert(err.response?.data?.message || err.message);
    }
  });

  const submitHandler = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      navigate('/login?redirect=checkout');
      return;
    }
    
    const itemsPrice = cartItems.reduce((acc, item) => acc + item.qty * item.price, 0);
    const shippingPrice = 0; // Free shipping
    const taxPrice = Number((0.15 * itemsPrice).toFixed(2)); // 15% dummy tax
    const totalPrice = itemsPrice + shippingPrice + taxPrice;

    orderMutation.mutate({
      orderItems: cartItems,
      shippingAddress: {
        street: address, // Map 'address' to 'street' for backend compatibility if needed
        city,
        postalCode,
        country,
      },
      paymentMethod,
      itemsPrice,
      taxPrice,
      shippingPrice,
      totalPrice,
    });
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <h1 className="text-3xl font-bold dark:text-white">Checkout</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-8">
          {/* Shipping Form */}
          <div className="bg-white dark:bg-dark-800 p-6 rounded-xl shadow-sm border border-gray-100 dark:border-dark-700">
            <h2 className="text-xl font-semibold dark:text-white mb-4">Shipping Address</h2>
            <form className="space-y-4" onSubmit={submitHandler}>
              <Input 
                label="Address" 
                value={address} 
                onChange={(e) => setAddress(e.target.value)} 
                required 
              />
              <div className="grid grid-cols-2 gap-4">
                <Input 
                  label="City" 
                  value={city} 
                  onChange={(e) => setCity(e.target.value)} 
                  required 
                />
                <Input 
                  label="Postal Code" 
                  value={postalCode} 
                  onChange={(e) => setPostalCode(e.target.value)} 
                  required 
                />
              </div>
              <Input 
                label="Country" 
                value={country} 
                onChange={(e) => setCountry(e.target.value)} 
                required 
              />
            </form>
          </div>

          {/* Payment Method */}
          <div className="bg-white dark:bg-dark-800 p-6 rounded-xl shadow-sm border border-gray-100 dark:border-dark-700">
            <h2 className="text-xl font-semibold dark:text-white mb-4">Payment Method</h2>
            <div className="space-y-2">
              <label className="flex items-center space-x-3 text-sm dark:text-gray-300">
                <input 
                  type="radio" 
                  value="Credit Card (Demo)" 
                  checked={paymentMethod === 'Credit Card (Demo)'} 
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="text-primary-600"
                />
                <span>Credit Card (Demo)</span>
              </label>
              <label className="flex items-center space-x-3 text-sm dark:text-gray-300">
                <input 
                  type="radio" 
                  value="PayPal" 
                  checked={paymentMethod === 'PayPal'} 
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="text-primary-600"
                />
                <span>PayPal</span>
              </label>
            </div>
          </div>
        </div>

        {/* Order Summary */}
        <div className="bg-white dark:bg-dark-800 p-6 rounded-xl shadow-sm border border-gray-100 dark:border-dark-700 h-fit">
          <h2 className="text-xl font-bold dark:text-white mb-6">Order Summary</h2>
          <div className="space-y-4 text-sm text-gray-600 dark:text-gray-300 mb-6 border-b border-gray-100 dark:border-dark-700 pb-6">
            {cartItems.map((item) => (
               <div key={item.product} className="flex justify-between">
                 <span className="truncate pr-4">{item.qty} x {item.name}</span>
                 <span className="font-medium">${(item.qty * item.price).toFixed(2)}</span>
               </div>
            ))}
          </div>

          <div className="space-y-4 text-sm text-gray-600 dark:text-gray-300">
            <div className="flex justify-between">
              <span>Items Total</span>
              <span className="font-semibold dark:text-white">
                ${cartItems.reduce((acc, item) => acc + item.qty * item.price, 0).toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between">
              <span>Shipping</span>
              <span className="font-semibold dark:text-white">Free</span>
            </div>
            <div className="border-t border-gray-200 dark:border-dark-700 pt-4 flex justify-between text-lg font-bold text-gray-900 dark:text-white">
              <span>Total</span>
              <span>${cartItems.reduce((acc, item) => acc + item.qty * item.price, 0).toFixed(2)}</span>
            </div>
          </div>
          <Button variant="primary" className="w-full mt-6" size="lg" onClick={submitHandler} disabled={orderMutation.isPending}>
            {orderMutation.isPending ? 'Placing Order...' : 'Place Order'}
          </Button>
        </div>
      </div>
    </div>
  );
};
