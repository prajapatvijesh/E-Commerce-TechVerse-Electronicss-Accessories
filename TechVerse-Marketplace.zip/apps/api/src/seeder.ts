import mongoose from 'mongoose';
import dotenv from 'dotenv';
import { User } from './models/User';
import { Product } from './models/Product';
import { Category } from './models/Category';
import { Brand } from './models/Brand';

dotenv.config();

const connectDB = async () => {
  try {
    const conn = await mongoose.connect(process.env.MONGODB_URI as string);
    console.log(`MongoDB Connected: ${conn.connection.host}`);
  } catch (error: any) {
    console.error(`Error: ${error.message}`);
    process.exit(1);
  }
};

const importData = async () => {
  try {
    await connectDB();

    await User.deleteMany();
    await Product.deleteMany();
    await Category.deleteMany();
    await Brand.deleteMany();

    console.log('Data Destroyed!');

    const createdUsers = await User.insertMany([
      { name: 'Admin', email: 'admin@techverse.com', password: 'password', role: 'admin' },
      { name: 'Vendor 1', email: 'vendor@test.com', password: 'password', role: 'vendor' },
      { name: 'Customer 1', email: 'customer@test.com', password: 'password', role: 'customer' }
    ]);

    console.log('Data Imported!');
    process.exit();
  } catch (error) {
    console.error(`${error}`);
    process.exit(1);
  }
};

const destroyData = async () => {
  try {
    await connectDB();

    await User.deleteMany();
    await Product.deleteMany();
    await Category.deleteMany();
    await Brand.deleteMany();

    console.log('Data Destroyed!');
    process.exit();
  } catch (error) {
    console.error(`${error}`);
    process.exit(1);
  }
};

if (process.argv[2] === '-d') {
  destroyData();
} else {
  importData();
}
