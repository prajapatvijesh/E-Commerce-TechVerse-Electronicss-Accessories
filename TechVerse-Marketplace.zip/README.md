# TechVerse - Multi-Vendor Electronics Marketplace

This is a COMPLETE production-ready Multi-Vendor Electronics & Accessories Marketplace called "TechVerse".

## Architecture
- **Monorepo**: Turborepo with pnpm workspaces
- **Frontend Apps**: 
  - `apps/web`: Customer-facing storefront (Vite + React + TailwindCSS + Redux Toolkit)
  - `apps/admin`: Vendor and Admin dashboard (Vite + React + TailwindCSS + Redux Toolkit)
- **Backend**:
  - `apps/api`: Express.js backend with MongoDB Atlas
- **Shared Packages**:
  - `packages/shared`: Shared Typescript types, Zod schemas, utilities.
  - `packages/ui`: Shared React components (Buttons, Inputs, Modals, Tables, etc.) styled with Tailwind CSS.

## Features Implemented
- Full JWT Authentication and Role-based routing (Customer, Vendor, Admin)
- Complete Product CRUD with Categories, Brands, and Vendors.
- Complete Shopping Cart, Wishlist, and Checkout flows.
- Reviews and Q&A models.
- Discount Coupons validation.
- PDF Invoice Generation using `pdfkit`.
- Global Settings and CMS system.
- Analytics and Notifications.
- Clean Code and Structured Folders.
- Backend and Frontend Unit Test scaffolding.

## How to Run

1. **Install dependencies from root**:
```bash
pnpm install
```

2. **Setup Environment Variables**:
- In `apps/api/.env`, configure your MongoDB Atlas URI, JWT_SECRET, Cloudinary details, etc.

3. **Start the Development Server (runs all apps concurrently)**:
```bash
pnpm run dev
```

4. **Access the Apps**:
- Web Store: `http://localhost:3000`
- Admin/Vendor Dashboard: `http://localhost:3001`
- Backend API: `http://localhost:5000`

## Build for Production
```bash
pnpm run build
```
