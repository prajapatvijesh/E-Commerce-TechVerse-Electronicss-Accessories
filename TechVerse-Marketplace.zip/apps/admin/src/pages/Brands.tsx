import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, Table, TableHeader, TableBody, TableRow, TableHead, TableCell, Badge, Input, Button, Modal } from '@techverse/ui';
import { Search, Edit, Trash2, Plus } from 'lucide-react';

export const Brands: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Dummy brands data
  const brands = [
    { id: '1', name: 'Apple', slug: 'apple', status: 'active' },
    { id: '2', name: 'Samsung', slug: 'samsung', status: 'active' },
    { id: '3', name: 'Sony', slug: 'sony', status: 'active' },
    { id: '4', name: 'Logitech', slug: 'logitech', status: 'active' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold dark:text-white">Brands Management</h1>
        <Button variant="primary" onClick={() => setIsModalOpen(true)} className="flex items-center space-x-2">
          <Plus size={16} />
          <span>Add Brand</span>
        </Button>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>All Brands</CardTitle>
          <div className="w-64 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
            <Input 
              placeholder="Search brands..." 
              className="pl-9 h-9" 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Slug</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {brands.map((brand) => (
                <TableRow key={brand.id}>
                  <TableCell className="font-medium dark:text-white">{brand.name}</TableCell>
                  <TableCell className="text-gray-500">{brand.slug}</TableCell>
                  <TableCell>
                    <Badge variant={brand.status === 'active' ? 'success' : 'error'}>
                      {brand.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right space-x-2">
                    <button className="text-gray-400 hover:text-primary-600 transition-colors p-1"><Edit size={16} /></button>
                    <button className="text-gray-400 hover:text-red-600 transition-colors p-1"><Trash2 size={16} /></button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Add New Brand">
        <form className="space-y-4">
          <Input label="Brand Name" placeholder="e.g. Dell" required />
          <Input label="Slug" placeholder="e.g. dell" />
          <div className="flex justify-end space-x-3 pt-4">
            <Button variant="outline" onClick={() => setIsModalOpen(false)} type="button">Cancel</Button>
            <Button variant="primary" type="submit">Save Brand</Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
