import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import axios from 'axios';
import { Button, Badge } from '@techverse/ui';
import { Star, ShoppingCart, Heart, ShieldCheck, Truck, RotateCcw } from 'lucide-react';
import { useDispatch } from 'react-redux';
import { addToCart } from '../store/slices/cartSlice';

export const ProductDetails: React.FC = () => {
  const { slug } = useParams();
  const [qty, setQty] = useState(1);
  const dispatch = useDispatch();

  const { data, isLoading, error } = useQuery({
    queryKey: ['product', slug],
    queryFn: async () => {
      const res = await axios.get(`/api/products/${slug}`);
      return res.data.data;
    },
    enabled: !!slug
  });

  if (isLoading) return <div className="dark:text-white">Loading product details...</div>;
  if (error || !data) return <div className="text-red-500">Error loading product details.</div>;

  const product = data;

  const handleAddToCart = () => {
    dispatch(addToCart({
      product: product._id,
      name: product.name,
      price: product.salePrice || product.price,
      image: product.thumbnail || product.images[0] || '',
      qty,
      vendor: product.vendor?._id || product.vendor
    }));
    alert('Added to cart!');
  };

  return (
    <div className="space-y-12">
      {/* Product Top */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        <div className="space-y-4">
          <div className="bg-white dark:bg-dark-800 aspect-square rounded-2xl overflow-hidden border border-gray-100 dark:border-dark-700 p-8 flex items-center justify-center">
            {product.thumbnail ? (
               <img src={product.thumbnail} alt={product.name} className="w-full h-full object-cover" />
            ) : (
               <div className="text-gray-400">No Image Available</div>
            )}
          </div>
        </div>

        <div className="space-y-6">
          <div>
            <Badge variant="info" className="mb-2">{product.brand?.name || 'Brand'}</Badge>
            <h1 className="text-3xl font-bold dark:text-white leading-tight">{product.name}</h1>
            <div className="flex items-center space-x-2 mt-2">
              <div className="flex text-yellow-400">
                <Star size={16} fill="currentColor" />
                <Star size={16} fill="currentColor" />
                <Star size={16} fill="currentColor" />
                <Star size={16} fill="currentColor" />
                <Star size={16} fill="currentColor" />
              </div>
              <span className="text-sm text-gray-500 dark:text-gray-400">({product.numReviews || 0} reviews)</span>
            </div>
            {product.vendor?.storeName && (
              <p className="text-sm text-gray-500 mt-2">Sold by: <span className="font-semibold">{product.vendor.storeName}</span></p>
            )}
          </div>

          <div className="text-3xl font-bold text-gray-900 dark:text-white">
            ${product.price?.toFixed(2)}
          </div>

          <p className="text-gray-600 dark:text-gray-300">
            {product.description}
          </p>

          <div className="space-y-4 pt-6 border-t border-gray-200 dark:border-dark-700">
            {product.stock > 0 ? (
              <div className="flex items-center space-x-4">
                <span className="text-sm font-medium dark:text-white">Quantity:</span>
                <select 
                  value={qty} 
                  onChange={e => setQty(Number(e.target.value))}
                  className="border border-gray-300 dark:border-dark-600 bg-white dark:bg-dark-800 rounded-md py-2 px-4 text-sm dark:text-white outline-none"
                >
                  {[...Array(product.stock).keys()].map(x => (
                    <option key={x + 1} value={x + 1}>{x + 1}</option>
                  ))}
                </select>
                <span className="text-sm text-gray-500 dark:text-gray-400">({product.stock} in stock)</span>
              </div>
            ) : (
              <div className="text-red-500 font-bold">Out of Stock</div>
            )}

            <div className="flex space-x-4">
              <Button variant="primary" size="lg" className="flex-1 flex justify-center items-center space-x-2" onClick={handleAddToCart} disabled={product.stock === 0}>
                <ShoppingCart size={20} />
                <span>Add to Cart</span>
              </Button>
              <Button variant="outline" size="lg" className="px-4">
                <Heart size={20} />
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-6 text-sm text-gray-600 dark:text-gray-400">
            <div className="flex items-center space-x-2">
              <Truck size={20} className="text-primary-600" />
              <span>Free Delivery</span>
            </div>
            <div className="flex items-center space-x-2">
              <RotateCcw size={20} className="text-primary-600" />
              <span>30 Days Return</span>
            </div>
            <div className="flex items-center space-x-2">
              <ShieldCheck size={20} className="text-primary-600" />
              <span>1 Year Warranty</span>
            </div>
          </div>
        </div>
      </div>
      
      {/* Product Details Tabs */}
      <div className="border-t border-gray-200 dark:border-dark-700 pt-12">
        <h2 className="text-2xl font-bold dark:text-white mb-6">Customer Reviews & Q&A</h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Reviews Section */}
          <div className="space-y-6">
            <h3 className="text-xl font-bold dark:text-white">Reviews</h3>
            
            {/* Add Review Form */}
            <div className="bg-gray-50 dark:bg-dark-800 p-6 rounded-xl border border-gray-100 dark:border-dark-700">
              <h4 className="font-semibold dark:text-white mb-4">Write a Review</h4>
              <form 
                className="space-y-4"
                onSubmit={(e) => {
                  e.preventDefault();
                  const form = e.target as HTMLFormElement;
                  const rating = (form.elements.namedItem('rating') as HTMLSelectElement).value;
                  const comment = (form.elements.namedItem('comment') as HTMLTextAreaElement).value;
                  axios.post('/api/reviews', { product: product._id, rating, comment }, {
                    headers: { Authorization: `Bearer ${localStorage.getItem('user') ? JSON.parse(localStorage.getItem('user')!).token : ''}` }
                  }).then(() => {
                    alert('Review submitted!');
                    window.location.reload();
                  }).catch(err => alert(err.response?.data?.message || err.message));
                }}
              >
                <select name="rating" className="w-full border border-gray-300 dark:border-dark-600 bg-white dark:bg-dark-900 rounded-md py-2 px-4 text-sm dark:text-white outline-none" required>
                  <option value="">Select Rating</option>
                  <option value="5">5 - Excellent</option>
                  <option value="4">4 - Good</option>
                  <option value="3">3 - Fair</option>
                  <option value="2">2 - Poor</option>
                  <option value="1">1 - Terrible</option>
                </select>
                <textarea name="comment" className="w-full border border-gray-300 dark:border-dark-600 bg-white dark:bg-dark-900 rounded-md py-2 px-4 text-sm dark:text-white outline-none h-24" placeholder="Your review..." required></textarea>
                <Button variant="primary" type="submit">Submit Review</Button>
              </form>
            </div>

            {/* List Reviews */}
            <div className="space-y-4">
              <ReviewsList productId={product._id} />
            </div>
          </div>

          {/* Q&A Section */}
          <div className="space-y-6">
            <h3 className="text-xl font-bold dark:text-white">Questions & Answers</h3>
            
            {/* Ask Question Form */}
            <div className="bg-gray-50 dark:bg-dark-800 p-6 rounded-xl border border-gray-100 dark:border-dark-700">
              <h4 className="font-semibold dark:text-white mb-4">Ask a Question</h4>
              <form 
                className="space-y-4"
                onSubmit={(e) => {
                  e.preventDefault();
                  const form = e.target as HTMLFormElement;
                  const question = (form.elements.namedItem('question') as HTMLTextAreaElement).value;
                  axios.post('/api/qa', { product: product._id, question }, {
                    headers: { Authorization: `Bearer ${localStorage.getItem('user') ? JSON.parse(localStorage.getItem('user')!).token : ''}` }
                  }).then(() => {
                    alert('Question submitted!');
                    window.location.reload();
                  }).catch(err => alert(err.response?.data?.message || err.message));
                }}
              >
                <textarea name="question" className="w-full border border-gray-300 dark:border-dark-600 bg-white dark:bg-dark-900 rounded-md py-2 px-4 text-sm dark:text-white outline-none h-24" placeholder="What would you like to know?" required></textarea>
                <Button variant="outline" type="submit">Ask Question</Button>
              </form>
            </div>

            {/* List QA */}
            <div className="space-y-4">
              <QAList productId={product._id} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Helper components for Reviews and QA
const ReviewsList = ({ productId }: { productId: string }) => {
  const { data, isLoading } = useQuery({
    queryKey: ['reviews', productId],
    queryFn: async () => {
      const res = await axios.get(`/api/reviews/${productId}`);
      return res.data.data;
    }
  });

  if (isLoading) return <div className="text-gray-500">Loading reviews...</div>;
  if (!data || data.length === 0) return <div className="text-gray-500">No reviews yet. Be the first!</div>;

  return (
    <>
      {data.map((r: any) => (
        <div key={r._id} className="border-b border-gray-200 dark:border-dark-700 pb-4">
          <div className="flex items-center space-x-2 mb-2">
            <span className="font-semibold dark:text-white">{r.user?.name || 'Anonymous'}</span>
            <span className="text-yellow-400 text-sm">★ {r.rating}</span>
          </div>
          <p className="text-gray-600 dark:text-gray-300 text-sm">{r.comment}</p>
        </div>
      ))}
    </>
  );
};

const QAList = ({ productId }: { productId: string }) => {
  const { data, isLoading } = useQuery({
    queryKey: ['qa', productId],
    queryFn: async () => {
      const res = await axios.get(`/api/qa/${productId}`);
      return res.data.data;
    }
  });

  if (isLoading) return <div className="text-gray-500">Loading Q&A...</div>;
  if (!data || data.length === 0) return <div className="text-gray-500">No questions yet.</div>;

  return (
    <>
      {data.map((q: any) => (
        <div key={q._id} className="border-b border-gray-200 dark:border-dark-700 pb-4">
          <p className="font-semibold dark:text-white text-sm mb-1">Q: {q.question}</p>
          {q.answer ? (
            <p className="text-gray-600 dark:text-gray-300 text-sm">A: {q.answer}</p>
          ) : (
            <p className="text-gray-400 text-sm italic">Pending answer...</p>
          )}
        </div>
      ))}
    </>
  );
};
