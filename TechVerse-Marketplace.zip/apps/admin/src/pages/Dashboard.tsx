import React from 'react';
import { useSelector } from 'react-redux';
import { useQuery } from '@tanstack/react-query';
import axios from 'axios';
import { RootState } from '../store/store';

export const Dashboard: React.FC = () => {
  const { user } = useSelector((state: RootState) => state.auth);

  const { data, isLoading, error } = useQuery({
    queryKey: ['analytics'],
    queryFn: async () => {
      const res = await axios.get('/api/analytics', {
        headers: { Authorization: `Bearer ${user?.token}` }
      });
      return res.data.data;
    }
  });

  if (isLoading) return <div className="dark:text-white">Loading dashboard...</div>;
  if (error) return <div className="text-red-500">Failed to load analytics</div>;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold dark:text-white">Dashboard overview, welcome {user?.name}!</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Metric Cards */}
        <div className="bg-white dark:bg-dark-800 p-6 rounded-xl shadow-sm border border-gray-100 dark:border-dark-700">
          <h3 className="text-gray-500 dark:text-gray-400 text-sm font-medium">Total Revenue</h3>
          <p className="text-3xl font-bold dark:text-white mt-2">${data?.totalRevenue?.toFixed(2) || '0.00'}</p>
        </div>
        <div className="bg-white dark:bg-dark-800 p-6 rounded-xl shadow-sm border border-gray-100 dark:border-dark-700">
          <h3 className="text-gray-500 dark:text-gray-400 text-sm font-medium">Total Orders</h3>
          <p className="text-3xl font-bold dark:text-white mt-2">{data?.totalOrders || 0}</p>
        </div>
        <div className="bg-white dark:bg-dark-800 p-6 rounded-xl shadow-sm border border-gray-100 dark:border-dark-700">
          <h3 className="text-gray-500 dark:text-gray-400 text-sm font-medium">Active Products</h3>
          <p className="text-3xl font-bold dark:text-white mt-2">{data?.totalProducts || 0}</p>
        </div>
      </div>
    </div>
  );
};
