import React, { useState } from 'react';
import { Button, Input } from '@techverse/ui';
import { Package, Heart, User, FileText } from 'lucide-react';

export const Dashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState('orders');

  return (
    <div className="flex flex-col md:flex-row gap-8">
      {/* Sidebar */}
      <aside className="w-full md:w-64 space-y-2">
        <button 
          onClick={() => setActiveTab('orders')}
          className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${activeTab === 'orders' ? 'bg-primary-50 text-primary-600 dark:bg-primary-900/30 dark:text-primary-400 font-medium' : 'text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-dark-800'}`}
        >
          <Package size={20} />
          <span>My Orders</span>
        </button>
        <button 
          onClick={() => setActiveTab('wishlist')}
          className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${activeTab === 'wishlist' ? 'bg-primary-50 text-primary-600 dark:bg-primary-900/30 dark:text-primary-400 font-medium' : 'text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-dark-800'}`}
        >
          <Heart size={20} />
          <span>Wishlist</span>
        </button>
        <button 
          onClick={() => setActiveTab('profile')}
          className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${activeTab === 'profile' ? 'bg-primary-50 text-primary-600 dark:bg-primary-900/30 dark:text-primary-400 font-medium' : 'text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-dark-800'}`}
        >
          <User size={20} />
          <span>Profile Settings</span>
        </button>
      </aside>

      {/* Main Content */}
      <div className="flex-1">
        {activeTab === 'orders' && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold dark:text-white mb-6">Order History</h2>
            {[1, 2].map((order) => (
              <div key={order} className="bg-white dark:bg-dark-800 rounded-xl border border-gray-100 dark:border-dark-700 overflow-hidden">
                <div className="bg-gray-50 dark:bg-dark-900 p-4 border-b border-gray-100 dark:border-dark-700 flex justify-between items-center text-sm">
                  <div>
                    <p className="text-gray-500 dark:text-gray-400">Order Placed</p>
                    <p className="font-semibold dark:text-white">July 4, 2026</p>
                  </div>
                  <div>
                    <p className="text-gray-500 dark:text-gray-400">Total</p>
                    <p className="font-semibold dark:text-white">$398.00</p>
                  </div>
                  <div>
                    <p className="text-gray-500 dark:text-gray-400">Order #</p>
                    <p className="font-semibold dark:text-white">ORD-284719</p>
                  </div>
                  <div>
                    <Button variant="outline" size="sm" className="flex items-center space-x-2">
                      <FileText size={16} />
                      <span>Invoice</span>
                    </Button>
                  </div>
                </div>
                <div className="p-6 flex items-center space-x-6">
                  <div className="w-20 h-20 bg-gray-200 dark:bg-dark-700 rounded-md"></div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-primary-600">Sony WH-1000XM5</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Qty: 1</p>
                  </div>
                  <div>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400">
                      Delivered
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'wishlist' && (
          <div>
            <h2 className="text-2xl font-bold dark:text-white mb-6">My Wishlist</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3].map((item) => (
                <div key={item} className="bg-white dark:bg-dark-800 rounded-xl p-4 border border-gray-100 dark:border-dark-700 flex flex-col group">
                  <div className="aspect-square bg-gray-100 dark:bg-dark-700 rounded-lg mb-4"></div>
                  <div className="mt-auto">
                    <h3 className="font-semibold text-gray-900 dark:text-white mb-2">Saved Product {item}</h3>
                    <div className="flex items-center justify-between mt-4">
                      <span className="text-lg font-bold text-gray-900 dark:text-white">$199.00</span>
                      <Button variant="primary" size="sm">Add to Cart</Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'profile' && (
          <div className="max-w-2xl bg-white dark:bg-dark-800 p-8 rounded-xl border border-gray-100 dark:border-dark-700">
            <h2 className="text-2xl font-bold dark:text-white mb-6">Profile Settings</h2>
            <form className="space-y-6">
              <Input label="Full Name" defaultValue="John Doe" />
              <Input label="Email Address" defaultValue="john@example.com" type="email" />
              <div className="pt-4 border-t border-gray-100 dark:border-dark-700">
                <h3 className="text-lg font-medium dark:text-white mb-4">Change Password</h3>
                <div className="space-y-4">
                  <Input label="Current Password" type="password" />
                  <Input label="New Password" type="password" />
                  <Input label="Confirm New Password" type="password" />
                </div>
              </div>
              <Button variant="primary">Save Changes</Button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
