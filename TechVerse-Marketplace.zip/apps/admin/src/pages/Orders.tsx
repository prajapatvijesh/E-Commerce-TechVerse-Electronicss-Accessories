import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, Table, TableHeader, TableBody, TableRow, TableHead, TableCell, Badge, Input } from '@techverse/ui';
import { Search, Eye } from 'lucide-react';

export const Orders: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');

  // Dummy orders data
  const orders = [
    { id: 'ORD-1001', customer: 'John Doe', total: 1299.00, status: 'delivered', date: '2026-07-01' },
    { id: 'ORD-1002', customer: 'Jane Smith', total: 349.50, status: 'processing', date: '2026-07-03' },
    { id: 'ORD-1003', customer: 'Alex Johnson', total: 45.00, status: 'shipped', date: '2026-07-04' },
    { id: 'ORD-1004', customer: 'Emily Davis', total: 899.99, status: 'cancelled', date: '2026-07-04' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold dark:text-white">Orders Management</h1>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Recent Orders</CardTitle>
          <div className="w-64 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
            <Input 
              placeholder="Search orders by ID..." 
              className="pl-9 h-9" 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Order ID</TableHead>
                <TableHead>Customer</TableHead>
                <TableHead>Total Amount</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Date</TableHead>
                <TableHead className="text-right">Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {orders.map((order) => (
                <TableRow key={order.id}>
                  <TableCell className="font-medium dark:text-white">{order.id}</TableCell>
                  <TableCell>{order.customer}</TableCell>
                  <TableCell>${order.total.toFixed(2)}</TableCell>
                  <TableCell>
                    <Badge variant={
                      order.status === 'delivered' ? 'success' : 
                      order.status === 'processing' ? 'warning' :
                      order.status === 'shipped' ? 'info' : 'error'
                    }>
                      {order.status}
                    </Badge>
                  </TableCell>
                  <TableCell>{order.date}</TableCell>
                  <TableCell className="text-right">
                    <button className="text-gray-400 hover:text-primary-600 transition-colors p-1"><Eye size={16} /></button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};
