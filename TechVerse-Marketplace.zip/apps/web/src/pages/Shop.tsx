import React from 'react';
import { useQuery } from '@tanstack/react-query';
import axios from 'axios';
import { Link } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { Button } from '@techverse/ui';
import { addToCart } from '../store/slices/cartSlice';

export const Shop: React.FC = () => {
  const dispatch = useDispatch();

  const { data, isLoading, error } = useQuery({
    queryKey: ['products'],
    queryFn: async () => {
      const res = await axios.get('/api/products');
      return res.data.data;
    }
  });

  const handleAddToCart = (product: any) => {
    dispatch(addToCart({
      product: product._id,
      name: product.name,
      price: product.salePrice || product.price,
      image: product.thumbnail || product.images[0] || '',
      qty: 1,
      vendor: product.vendor
    }));
    alert('Added to cart!');
  };

  return (
    <div className="flex flex-col md:flex-row gap-8">
      {/* Filters Sidebar */}
      <aside className="w-full md:w-64 space-y-6">
        <div>
          <h3 className="font-bold text-lg mb-4 dark:text-white">Categories</h3>
          <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
            <li><label className="flex items-center space-x-2"><input type="checkbox" className="rounded text-primary-600" /> <span>Smartphones</span></label></li>
            <li><label className="flex items-center space-x-2"><input type="checkbox" className="rounded text-primary-600" /> <span>Laptops</span></label></li>
            <li><label className="flex items-center space-x-2"><input type="checkbox" className="rounded text-primary-600" /> <span>Audio</span></label></li>
          </ul>
        </div>
        <div>
          <h3 className="font-bold text-lg mb-4 dark:text-white">Price Range</h3>
          <input type="range" className="w-full accent-primary-600" />
        </div>
      </aside>

      {/* Product Grid */}
      <div className="flex-1">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold dark:text-white">All Products</h2>
          <select className="border border-gray-300 dark:border-dark-600 bg-white dark:bg-dark-800 rounded-md py-2 px-4 text-sm dark:text-white outline-none">
            <option>Sort by: Featured</option>
            <option>Price: Low to High</option>
            <option>Price: High to Low</option>
            <option>Newest Arrivals</option>
          </select>
        </div>

        {isLoading ? (
          <div className="dark:text-white">Loading products...</div>
        ) : error ? (
          <div className="text-red-500">Error loading products.</div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {data?.products?.map((product: any) => (
              <div key={product._id} className="bg-white dark:bg-dark-800 rounded-xl p-4 border border-gray-100 dark:border-dark-700 flex flex-col group hover:shadow-xl transition-shadow duration-300">
                <Link to={`/product/${product.slug}`} className="aspect-square bg-gray-100 dark:bg-dark-700 rounded-lg mb-4 overflow-hidden flex items-center justify-center relative">
                  {product.thumbnail ? (
                    <img src={product.thumbnail} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                  ) : (
                    <span className="text-gray-400">No Image</span>
                  )}
                </Link>
                <div className="mt-auto">
                  <h3 className="font-semibold text-gray-900 dark:text-white mb-2 line-clamp-2 group-hover:text-primary-600 transition-colors">
                    <Link to={`/product/${product.slug}`}>{product.name}</Link>
                  </h3>
                  <div className="flex items-center justify-between mt-4">
                    <span className="text-lg font-bold text-gray-900 dark:text-white">${product.price}</span>
                    <Button variant="primary" size="sm" onClick={() => handleAddToCart(product)}>Add</Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
