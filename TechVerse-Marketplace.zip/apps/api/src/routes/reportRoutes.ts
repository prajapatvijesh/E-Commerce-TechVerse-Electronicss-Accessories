import express from 'express';
import { protect, authorize } from '../middleware/authMiddleware';
import { getSalesReport, getActivityLogs } from '../controllers/reportController';

const router = express.Router();

router.route('/sales')
  .get(protect, authorize('admin', 'superadmin'), getSalesReport);

router.route('/activity')
  .get(protect, authorize('admin', 'superadmin'), getActivityLogs);

export default router;
