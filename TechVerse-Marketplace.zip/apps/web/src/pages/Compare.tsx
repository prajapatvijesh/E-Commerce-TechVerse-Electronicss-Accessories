import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '@techverse/ui';

export const Compare: React.FC = () => {
  return (
    <div className="space-y-6 max-w-7xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold dark:text-white">Product Comparison</h1>

      <Card>
        <CardHeader>
          <CardTitle>Compare Items</CardTitle>
        </CardHeader>
        <CardContent className="p-0 overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Feature</TableHead>
                <TableHead>Sony WH-1000XM5</TableHead>
                <TableHead>Apple AirPods Max</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow>
                <TableCell className="font-semibold">Price</TableCell>
                <TableCell>$398.00</TableCell>
                <TableCell>$549.00</TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-semibold">Brand</TableCell>
                <TableCell>Sony</TableCell>
                <TableCell>Apple</TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-semibold">Battery Life</TableCell>
                <TableCell>30 Hours</TableCell>
                <TableCell>20 Hours</TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};
