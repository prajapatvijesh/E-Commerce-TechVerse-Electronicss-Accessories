import React from 'react';
import { Outlet, Link } from 'react-router-dom';
import { ShoppingCart, Search, User, Menu } from 'lucide-react';
import { Button } from '@techverse/ui';
import { useSelector } from 'react-redux';
import { RootState } from '../store/store';

export const MainLayout: React.FC = () => {
  const cartItems = useSelector((state: RootState) => state.cart.cartItems);

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-dark-900 transition-colors">
      {/* Header */}
      <header className="bg-white dark:bg-dark-800 shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            {/* Logo */}
            <div className="flex items-center">
              <Link to="/" className="flex-shrink-0 flex items-center">
                <span className="text-2xl font-bold text-primary-600 tracking-tighter">TechVerse</span>
              </Link>
            </div>

            {/* Search Bar */}
            <div className="hidden sm:flex flex-1 max-w-2xl mx-8">
              <div className="relative w-full">
                <input
                  type="text"
                  placeholder="Search for electronics, accessories, brands..."
                  className="w-full bg-gray-100 dark:bg-dark-700 border-transparent focus:bg-white dark:focus:bg-dark-800 focus:border-primary-500 focus:ring-2 focus:ring-primary-500 rounded-lg pl-10 pr-4 py-2 text-sm dark:text-white"
                />
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
              </div>
            </div>

            {/* Nav Actions */}
            <div className="flex items-center space-x-4">
              <Link to="/cart" className="relative p-2 text-gray-600 dark:text-gray-300 hover:text-primary-600 transition-colors">
                <ShoppingCart size={24} />
                {cartItems.length > 0 && (
                  <span className="absolute top-0 right-0 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-white transform translate-x-1/2 -translate-y-1/2 bg-red-600 rounded-full">
                    {cartItems.length}
                  </span>
                )}
              </Link>
              <Button variant="ghost" className="hidden sm:flex items-center space-x-2">
                <User size={20} />
                <span>Sign In</span>
              </Button>
              <button className="sm:hidden p-2 text-gray-600 dark:text-gray-300">
                <Menu size={24} />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="bg-white dark:bg-dark-800 border-t border-gray-200 dark:border-dark-700 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <span className="text-xl font-bold text-primary-600 tracking-tighter">TechVerse</span>
              <p className="mt-4 text-sm text-gray-500 dark:text-gray-400">
                The ultimate destination for premium electronics and accessories.
              </p>
            </div>
            <div>
              <h3 className="text-sm font-semibold text-gray-900 dark:text-white uppercase tracking-wider">Shop</h3>
              <ul className="mt-4 space-y-2 text-sm text-gray-500 dark:text-gray-400">
                <li><Link to="/shop?category=smartphones" className="hover:text-primary-600">Smartphones</Link></li>
                <li><Link to="/shop?category=laptops" className="hover:text-primary-600">Laptops</Link></li>
                <li><Link to="/shop?category=accessories" className="hover:text-primary-600">Accessories</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="text-sm font-semibold text-gray-900 dark:text-white uppercase tracking-wider">Support</h3>
              <ul className="mt-4 space-y-2 text-sm text-gray-500 dark:text-gray-400">
                <li><Link to="/contact" className="hover:text-primary-600">Contact Us</Link></li>
                <li><Link to="/faq" className="hover:text-primary-600">FAQ</Link></li>
                <li><Link to="/returns" className="hover:text-primary-600">Returns Policy</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="text-sm font-semibold text-gray-900 dark:text-white uppercase tracking-wider">Sell with us</h3>
              <ul className="mt-4 space-y-2 text-sm text-gray-500 dark:text-gray-400">
                <li><a href="http://localhost:3001" className="hover:text-primary-600">Vendor Portal</a></li>
              </ul>
            </div>
          </div>
          <div className="mt-8 border-t border-gray-200 dark:border-dark-700 pt-8 flex justify-between items-center text-sm text-gray-500">
            <p>&copy; 2026 TechVerse Inc. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};
