import React from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import axios from 'axios';
import { useDispatch } from 'react-redux';
import { Button } from '@techverse/ui';
import { motion } from 'framer-motion';
import { addToCart } from '../store/slices/cartSlice';

export const Home: React.FC = () => {
  const dispatch = useDispatch();

  const { data, isLoading, error } = useQuery({
    queryKey: ['products', 'trending'],
    queryFn: async () => {
      const res = await axios.get('/api/products?limit=4');
      return res.data.data;
    }
  });

  const handleAddToCart = (product: any) => {
    dispatch(addToCart({
      product: product._id,
      name: product.name,
      price: product.salePrice || product.price,
      image: product.thumbnail || product.images[0] || '',
      qty: 1,
      vendor: product.vendor
    }));
    alert('Added to cart!');
  };

  return (
    <div className="space-y-16">
      {/* Hero Section */}
      <section className="relative rounded-2xl overflow-hidden bg-dark-900 text-white h-[500px] flex items-center">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1550009158-9efff6c624ff?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&q=80" 
            alt="Hero Background" 
            className="w-full h-full object-cover opacity-40"
          />
        </div>
        <div className="relative z-10 px-8 md:px-16 max-w-3xl">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-4xl md:text-6xl font-bold mb-4 tracking-tight"
          >
            The Future of Tech is Here.
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-lg md:text-xl text-gray-300 mb-8"
          >
            Discover the latest smartphones, laptops, and smart home devices from top brands at unbeatable prices.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <Link to="/shop">
              <Button size="lg" variant="primary" className="font-semibold text-lg">
                Shop Now
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Featured Categories */}
      <section>
        <div className="flex justify-between items-end mb-6">
          <h2 className="text-2xl font-bold dark:text-white">Shop by Category</h2>
          <Link to="/categories" className="text-primary-600 hover:underline font-medium">View All</Link>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
          {['Smartphones', 'Laptops', 'Audio', 'Smart Watches'].map((category, i) => (
            <Link key={i} to={`/shop?category=${category.toLowerCase()}`} className="group block">
              <div className="bg-white dark:bg-dark-800 rounded-xl p-6 border border-gray-100 dark:border-dark-700 text-center hover:shadow-lg transition-shadow duration-300">
                <div className="h-24 w-24 mx-auto bg-gray-100 dark:bg-dark-700 rounded-full mb-4 group-hover:scale-105 transition-transform"></div>
                <h3 className="font-semibold text-gray-900 dark:text-white group-hover:text-primary-600 transition-colors">{category}</h3>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured Products */}
      <section>
        <div className="flex justify-between items-end mb-6">
          <h2 className="text-2xl font-bold dark:text-white">Trending Products</h2>
        </div>
        
        {isLoading ? (
          <div className="dark:text-white">Loading trending products...</div>
        ) : error ? (
          <div className="text-red-500">Error loading products.</div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {data?.products?.map((product: any) => (
              <div key={product._id} className="bg-white dark:bg-dark-800 rounded-xl p-4 border border-gray-100 dark:border-dark-700 flex flex-col group hover:shadow-xl transition-shadow duration-300">
                <Link to={`/product/${product.slug}`} className="aspect-square bg-gray-100 dark:bg-dark-700 rounded-lg mb-4 overflow-hidden flex items-center justify-center relative">
                  {product.thumbnail ? (
                    <img src={product.thumbnail} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                  ) : (
                    <span className="text-gray-400">No Image</span>
                  )}
                </Link>
                <div className="mt-auto">
                  <h3 className="font-semibold text-gray-900 dark:text-white mb-2 line-clamp-2 group-hover:text-primary-600 transition-colors">
                    <Link to={`/product/${product.slug}`}>{product.name}</Link>
                  </h3>
                  <div className="flex items-center justify-between mt-4">
                    <span className="text-lg font-bold text-gray-900 dark:text-white">${product.price}</span>
                    <Button variant="primary" size="sm" onClick={() => handleAddToCart(product)}>Add</Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};
