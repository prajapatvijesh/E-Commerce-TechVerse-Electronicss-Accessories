import express from 'express';
import { protect } from '../middleware/authMiddleware';
import {
  createReview,
  getProductReviews
} from '../controllers/reviewController';

const router = express.Router();

router.route('/')
  .post(protect, createReview);

router.route('/:productId')
  .get(getProductReviews);

export default router;
