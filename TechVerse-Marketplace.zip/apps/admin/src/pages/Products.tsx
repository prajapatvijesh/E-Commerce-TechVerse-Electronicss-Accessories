import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import axios from 'axios';
import { Button, Modal } from '@techverse/ui';
import { Plus, Search, Edit, Trash } from 'lucide-react';
import { useForm } from 'react-hook-form';

export const Products: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<any>(null);
  
  const queryClient = useQueryClient();
  const { register, handleSubmit, reset, setValue } = useForm();

  // Fetch products
  const { data: productsData, isLoading } = useQuery({
    queryKey: ['products'],
    queryFn: async () => {
      const res = await axios.get('/api/products');
      return res.data;
    }
  });

  const products = productsData?.data || [];

  // Mutations
  const createMutation = useMutation({
    mutationFn: (newProduct: any) => axios.post('/api/products', newProduct),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['products'] });
      closeModal();
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string, data: any }) => axios.put(`/api/products/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['products'] });
      closeModal();
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => axios.delete(`/api/products/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['products'] });
    }
  });

  const onSubmit = (data: any) => {
    // Convert strings to numbers for price/stock
    let parsedVariants = [];
    try {
      if (data.variantsJson) {
        parsedVariants = JSON.parse(data.variantsJson);
      }
    } catch (e) {
      alert("Invalid JSON format for Variants!");
      return;
    }

    const payload = {
      ...data,
      price: Number(data.price),
      stock: Number(data.countInStock),
      variants: parsedVariants
    };

    if (editingProduct) {
      updateMutation.mutate({ id: editingProduct._id, data: payload });
    } else {
      createMutation.mutate(payload);
    }
  };

  const handleEdit = (product: any) => {
    setEditingProduct(product);
    setValue('name', product.name);
    setValue('brand', product.brand);
    setValue('category', product.category);
    setValue('description', product.description);
    setValue('price', product.price);
    setValue('countInStock', product.stock);
    setValue('sku', product.sku);
    setValue('variantsJson', product.variants ? JSON.stringify(product.variants) : '');
    setIsModalOpen(true);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this product?')) {
      deleteMutation.mutate(id);
    }
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingProduct(null);
    reset();
  };

  const filteredProducts = products.filter((p: any) => 
    p.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold dark:text-white">Products</h1>
        <Button variant="primary" className="flex items-center space-x-2" onClick={() => setIsModalOpen(true)}>
          <Plus size={16} />
          <span>Add Product</span>
        </Button>
      </div>

      <div className="bg-white dark:bg-dark-800 rounded-xl shadow-sm border border-gray-100 dark:border-dark-700 overflow-hidden">
        <div className="p-4 border-b border-gray-100 dark:border-dark-700 flex justify-between items-center">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input 
              type="text" 
              placeholder="Search products..." 
              className="pl-10 pr-4 py-2 border border-gray-300 dark:border-dark-600 rounded-md focus:outline-none focus:ring-1 focus:ring-primary-500 dark:bg-dark-700 dark:text-white"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-50 dark:bg-dark-900 border-b border-gray-200 dark:border-dark-700">
                <th className="px-6 py-4 text-sm font-semibold text-gray-600 dark:text-gray-300">Name</th>
                <th className="px-6 py-4 text-sm font-semibold text-gray-600 dark:text-gray-300">Category</th>
                <th className="px-6 py-4 text-sm font-semibold text-gray-600 dark:text-gray-300">Price</th>
                <th className="px-6 py-4 text-sm font-semibold text-gray-600 dark:text-gray-300">Stock</th>
                <th className="px-6 py-4 text-sm font-semibold text-gray-600 dark:text-gray-300 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 dark:divide-dark-700">
              {isLoading ? (
                <tr>
                  <td colSpan={5} className="text-center py-4 text-gray-500">Loading products...</td>
                </tr>
              ) : filteredProducts.map((product: any) => (
                <tr key={product._id} className="hover:bg-gray-50 dark:hover:bg-dark-700/50 transition-colors">
                  <td className="px-6 py-4 text-sm text-gray-900 dark:text-white font-medium">{product.name}</td>
                  <td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-400">{product.category}</td>
                  <td className="px-6 py-4 text-sm text-gray-900 dark:text-white">${product.price}</td>
                  <td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-400">{product.countInStock}</td>
                  <td className="px-6 py-4 text-sm text-right space-x-2">
                    <button onClick={() => handleEdit(product)} className="text-gray-400 hover:text-primary-600 transition-colors"><Edit size={16} /></button>
                    <button onClick={() => handleDelete(product._id)} className="text-gray-400 hover:text-red-600 transition-colors"><Trash size={16} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <Modal isOpen={isModalOpen} onClose={closeModal} title={editingProduct ? "Edit Product" : "Add Product"}>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium dark:text-white">Product Name</label>
            <input {...register('name')} required className="w-full px-3 py-2 border rounded-md dark:bg-dark-700 dark:border-dark-600 dark:text-white" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium dark:text-white">Brand</label>
              <input {...register('brand')} required className="w-full px-3 py-2 border rounded-md dark:bg-dark-700 dark:border-dark-600 dark:text-white" />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium dark:text-white">Category</label>
              <input {...register('category')} required className="w-full px-3 py-2 border rounded-md dark:bg-dark-700 dark:border-dark-600 dark:text-white" />
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium dark:text-white">Description</label>
            <textarea {...register('description')} required className="w-full px-3 py-2 border rounded-md dark:bg-dark-700 dark:border-dark-600 dark:text-white" rows={3}></textarea>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium dark:text-white">Price ($)</label>
              <input type="number" step="0.01" {...register('price')} required className="w-full px-3 py-2 border rounded-md dark:bg-dark-700 dark:border-dark-600 dark:text-white" />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium dark:text-white">Stock</label>
              <input type="number" {...register('countInStock')} required className="w-full px-3 py-2 border rounded-md dark:bg-dark-700 dark:border-dark-600 dark:text-white" />
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium dark:text-white">SKU</label>
            <input {...register('sku')} required placeholder="e.g. TECH-PHONE-123" className="w-full px-3 py-2 border rounded-md dark:bg-dark-700 dark:border-dark-600 dark:text-white" />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium dark:text-white">Variants (JSON Array)</label>
            <textarea {...register('variantsJson')} placeholder='[{"name":"Color","options":[{"name":"Red","price":10,"stock":5}]}]' className="w-full px-3 py-2 border rounded-md dark:bg-dark-700 dark:border-dark-600 dark:text-white font-mono text-sm" rows={3}></textarea>
            <p className="text-xs text-gray-500">Provide variants as a valid JSON array.</p>
          </div>
          <div className="pt-4 flex justify-end space-x-2">
            <Button type="button" variant="outline" onClick={closeModal}>Cancel</Button>
            <Button type="submit" variant="primary">
              {editingProduct ? 'Update Product' : 'Create Product'}
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
