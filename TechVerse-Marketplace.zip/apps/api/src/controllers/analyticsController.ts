import { Request, Response } from 'express';
import { Order } from '../models/Order';
import { Product } from '../models/Product';
import { User } from '../models/User';
import { AuthRequest } from '../middleware/authMiddleware';

// @desc    Get dashboard analytics
// @route   GET /api/analytics
// @access  Private/Admin/Vendor
export const getAnalytics = async (req: AuthRequest, res: Response) => {
  try {
    const isVendor = req.user?.role === 'vendor';
    
    // For vendor, we'd normally filter by vendor ID. Since orders just store generic items here, 
    // we assume for now this gives global stats for Admin.
    
    const totalOrders = await Order.countDocuments();
    const totalProducts = await Product.countDocuments(isVendor ? { vendor: req.user?._id } : {});
    const totalUsers = await User.countDocuments({ role: 'customer' });

    const orders = await Order.find();
    const totalRevenue = orders.reduce((acc, order) => acc + order.totalPrice, 0);

    res.json({
      status: 'success',
      data: {
        totalOrders,
        totalProducts,
        totalUsers: isVendor ? 0 : totalUsers, // Vendors don't see total global users
        totalRevenue
      }
    });
  } catch (error: any) {
    res.status(500).json({ status: 'error', message: error.message });
  }
};
