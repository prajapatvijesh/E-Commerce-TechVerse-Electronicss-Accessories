import { Response } from 'express';
import { Order } from '../models/Order';
import { AuthRequest } from '../middleware/authMiddleware';
import PDFDocument from 'pdfkit';

// @desc    Download order invoice PDF
// @route   GET /api/orders/:id/invoice
// @access  Private
export const downloadInvoice = async (req: AuthRequest, res: Response) => {
  try {
    const order = await Order.findById(req.params.id).populate('user', 'name email');

    if (!order) {
      return res.status(404).json({ status: 'error', message: 'Order not found' });
    }

    // Ensure user requesting is the order owner or an admin/vendor
    if (order.user._id.toString() !== req.user?._id.toString() && req.user?.role === 'customer') {
      return res.status(403).json({ status: 'error', message: 'Not authorized' });
    }

    // Create PDF
    const doc = new PDFDocument({ margin: 50 });

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename=invoice-${order._id}.pdf`);
    
    doc.pipe(res);

    // Header
    doc
      .fontSize(20)
      .text('TechVerse Invoice', { align: 'center' })
      .moveDown();

    doc
      .fontSize(12)
      .text(`Order ID: ${order._id}`)
      .text(`Date: ${order.createdAt.toString().substring(0, 10)}`)
      .moveDown();

    // Customer details
    doc
      .fontSize(14)
      .text('Customer Details')
      .fontSize(10)
      .text(`Name: ${(order.user as any).name}`)
      .text(`Email: ${(order.user as any).email}`)
      .moveDown();

    // Items
    doc.fontSize(14).text('Items ordered').moveDown(0.5);
    
    let y = doc.y;
    doc.fontSize(10);
    doc.text('Product', 50, y);
    doc.text('Qty', 300, y, { width: 50, align: 'right' });
    doc.text('Price', 400, y, { width: 50, align: 'right' });
    doc.text('Total', 500, y, { width: 50, align: 'right' });
    
    doc.moveDown();

    let subtotal = 0;
    order.orderItems.forEach((item: any) => {
      y = doc.y;
      doc.text(item.name || 'Product', 50, y, { width: 240 });
      doc.text(item.quantity.toString(), 300, y, { width: 50, align: 'right' });
      doc.text(`$${item.price.toFixed(2)}`, 400, y, { width: 50, align: 'right' });
      
      const total = item.quantity * item.price;
      subtotal += total;
      doc.text(`$${total.toFixed(2)}`, 500, y, { width: 50, align: 'right' });
      doc.moveDown();
    });

    doc.moveDown();
    y = doc.y;
    doc.fontSize(12);
    doc.text('Subtotal:', 400, y, { width: 50, align: 'right' });
    doc.text(`$${subtotal.toFixed(2)}`, 500, y, { width: 50, align: 'right' });
    
    doc.moveDown(0.5);
    y = doc.y;
    doc.text('Tax:', 400, y, { width: 50, align: 'right' });
    doc.text(`$${order.taxPrice.toFixed(2)}`, 500, y, { width: 50, align: 'right' });
    
    doc.moveDown(0.5);
    y = doc.y;
    doc.text('Shipping:', 400, y, { width: 50, align: 'right' });
    doc.text(`$${order.shippingPrice.toFixed(2)}`, 500, y, { width: 50, align: 'right' });

    doc.moveDown();
    y = doc.y;
    doc.fontSize(14).font('Helvetica-Bold');
    doc.text('Grand Total:', 350, y, { width: 100, align: 'right' });
    doc.text(`$${order.totalPrice.toFixed(2)}`, 500, y, { width: 50, align: 'right' });

    doc.end();

  } catch (error: any) {
    res.status(500).json({ status: 'error', message: error.message });
  }
};
