import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, Input, Button } from '@techverse/ui';

export const Settings: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold dark:text-white">Store Settings</h1>
        <Button variant="primary">Save Changes</Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>General Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Input label="Store Name" defaultValue="TechVerse Global" />
            <Input label="Support Email" defaultValue="support@techverse.com" />
            <Input label="Phone Number" defaultValue="+1 234 567 890" />
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Store Description
              </label>
              <textarea 
                className="w-full rounded-md border border-gray-300 bg-transparent px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 dark:border-dark-700 dark:text-gray-100 min-h-[100px]"
                defaultValue="The ultimate electronics marketplace."
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Payment & Tax</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Input label="Currency" defaultValue="USD ($)" />
            <Input label="Tax Rate (%)" defaultValue="10" type="number" />
            <Input label="Stripe Public Key" type="password" defaultValue="pk_test_123456789" />
            <Input label="PayPal Client ID" type="password" defaultValue="client_123456789" />
          </CardContent>
        </Card>

        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Social Links</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input label="Facebook URL" defaultValue="https://facebook.com/techverse" />
            <Input label="Twitter URL" defaultValue="https://twitter.com/techverse" />
            <Input label="Instagram URL" defaultValue="https://instagram.com/techverse" />
            <Input label="LinkedIn URL" defaultValue="https://linkedin.com/company/techverse" />
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
